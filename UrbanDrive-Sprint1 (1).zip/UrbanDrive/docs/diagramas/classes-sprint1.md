# Diagrama de classes — Sprint 1

```mermaid
classDiagram
    class Veiculo {
        -int _id
        -string _placa
        -string _modelo
        -decimal _valorBaseDiaria
        +int Id
        +string Placa
        +string Modelo
        +decimal ValorBaseDiaria
        +decimal ValorDiariaPadrao$
        +Veiculo(int id, string placa, string modelo, decimal valorBaseDiaria)
        +Veiculo(int id, string placa, string modelo)
        +ToString() string
    }
```

Regras de validação: `Id > 0`; `Placa` e `Modelo` não nulos/vazios; `ValorBaseDiaria > 0`.
