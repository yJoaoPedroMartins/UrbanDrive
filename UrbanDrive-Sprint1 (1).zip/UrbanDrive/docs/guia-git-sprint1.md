# Guia de Git — Sprint 1

Cada integrante deve ter commits próprios. Sugestão de divisão (igual ao planejamento):

| Integrante | Branch | Commits sugeridos |
|---|---|---|
| João Pedro dos Santos Martins | `docs/planejamento-sprint-1` e `feature/demo-console` | `chore: cria solucao e estrutura de pastas` · `docs: adiciona product backlog inicial` · `docs: adiciona planejamento da sprint 1` · `feat: adiciona demonstracao em console` |
| Gabriel Henrique Duarte Ferraz | `feature/classe-veiculo` | `feat: cria classe Veiculo com propriedades` · `feat: adiciona construtores de Veiculo` · `feat: implementa validacao da placa` |
| Victor Bryan Ferreira Lopes | `feature/testes-veiculo` | `docs: adiciona diagrama de classes inicial` · `test: adiciona testes de validacao de Veiculo` · `docs: registra evidencias de testes da sprint 1` |

## Fluxo

```bash
git clone <url-do-github-classroom>
git checkout -b feature/classe-veiculo
# ...trabalhar...
git add . && git commit -m "feat: implementa validacao da placa"
git push -u origin feature/classe-veiculo
# abrir Pull Request para main; outro integrante revisa e faz o merge
```

Ao final: `dotnet test`, salvar a saída em `docs/evidencias/saida-testes-sprint1.txt` e atualizar a seção G do planejamento com a situação real.
