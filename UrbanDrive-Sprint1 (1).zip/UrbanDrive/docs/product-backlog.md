# Product Backlog — UrbanDrive

> Versão inicial (Sprint 1). Prioridade: **Alta / Média / Baixa**. Estimativa em **pontos de história** (escala 1, 2, 3, 5, 8).
> Este arquivo deve ser atualizado a cada sprint; o histórico fica no Git.

| ID | Requisito / item | Origem | Prioridade | Depende de | Pontos | Sprint prevista | Status |
|----|------------------|--------|-----------|------------|--------|-----------------|--------|
| PB01 | Criar projeto C# (solução, projetos Models/App/Tests) e configurar repositório GitHub | Sprint 1 | Alta | — | 2 | 1 | Concluído |
| PB02 | Representar veículo: identificador, placa, modelo, valor-base da diária (**RF01**) | RF01 | Alta | PB01 | 3 | 1 | Concluído |
| PB03 | Encapsulamento: atributos privados e propriedades públicas; construtores | RF01 | Alta | PB02 | 2 | 1 | Concluído |
| PB04 | Validação de dados (placa nula/vazia e demais campos) | RF01 | Alta | PB03 | 3 | 1 | Concluído |
| PB05 | Testes iniciais de instanciação e validação + demonstração em console | RF01 / RF10 (parcial) | Alta | PB04 | 3 | 1 | Concluído |
| PB06 | Composição Motorista–CNH (**RF03**) | RF03 | Alta | PB02 | 5 | 2 | Pendente |
| PB07 | Agregação Frota–Veiculo (**RF04**) | RF04 | Alta | PB02 | 3 | 2 | Pendente |
| PB08 | ConfiguradorSistema com membros estáticos (**RF07**) | RF07 | Média | PB02 | 3 | 2 | Pendente |
| PB09 | Diagrama de classes (inicial e atualizações) | Sprints 1–4 | Média | PB02 | 2 | 1–4 | Em andamento |
| PB10 | Classes Carro e Patinete (herança, `sealed`) (**RF02**) | RF02 | Alta | PB02 | 5 | 3 | Pendente |
| PB11 | CalcularAluguel(int dias) com sobrescrita (**RF05**) | RF05 | Alta | PB10, PB08 | 5 | 3 | Pendente |
| PB12 | Sobrecarga RealizarManutencao() / RealizarManutencao(string) (**RF06**) | RF06 | Média | PB10 | 3 | 3 | Pendente |
| PB13 | Locação (entidade de aluguel) | Seção 3.1 | Média | PB11, PB06 | 5 | 3–4 | Pendente |
| PB14 | Veiculo abstrata + interface IImprimivel / GerarRelatorio() (**RF08**) | RF08 | Alta | PB10 | 5 | 4 | Pendente |
| PB15 | Interface IEletrico / Recarregar(); CarroEletrico (**RF09**) | RF09 | Alta | PB10, PB14 | 5 | 4 | Pendente |
| PB16 | Menu de console: cadastrar e consultar veículos (**RF10**) | RF10 | Alta | PB14 | 5 | 4 | Pendente |
| PB17 | Testes finais, documentação de instalação/execução, relatório final | Sprint 4 | Alta | todos | 5 | 4 | Pendente |

## Dependências principais

- PB02 (Veiculo) é a base de quase tudo, por isso é o centro da Sprint 1.
- PB11 (cálculo de aluguel) depende de PB10 (herança) e se beneficia de PB08 (taxas compartilhadas).
- PB14/PB15 (abstração e interfaces) só fazem sentido depois da hierarquia da Sprint 3.

## Decisões de projeto registradas

- **D1 — Pontos de história como unidade de estimativa**, com tarefas individuais em horas no documento de cada sprint.
- **D2 — Veiculo concreta na Sprint 1.** O enunciado exige instanciar objetos e testar na Sprint 1; a transformação em `abstract` fica para a Sprint 4, conforme o enunciado.
- **D3 — Validações além da placa.** O enunciado exige a restrição de placa nula/vazia; o grupo também validou Id > 0, modelo não vazio e diária > 0, por serem invariantes necessárias para os cálculos das sprints seguintes.
