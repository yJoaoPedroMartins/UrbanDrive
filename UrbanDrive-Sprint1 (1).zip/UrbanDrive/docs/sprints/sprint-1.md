# Planejamento da Sprint 1 — UrbanDrive

## A. Identificação

- **Grupo:** UrbanDrive — Trabalho Prático de POO (PUC Minas)
- **Integrantes:** Gabriel Henrique Duarte Ferraz; João Pedro dos Santos Martins; Victor Bryan Ferreira Lopes
- **Número da sprint:** 1
- **Período:** 26/10/2026 a 01/11/2026 _(ajustar se o grupo combinou outras datas)_
- **Responsável pelo acompanhamento:** João Pedro dos Santos Martins

## B. Objetivo da sprint

Entregar uma primeira versão **executável** do UrbanDrive em que um veículo é representado por uma classe `Veiculo` bem encapsulada (atributos privados, propriedades públicas, construtores) e **protegida por validações**, com a estrutura do projeto e do repositório prontas para as próximas sprints, e com testes que provem o funcionamento das validações.

## C. Itens selecionados do Product Backlog

| ID | Requisito ou item | Prioridade | Justificativa |
|----|-------------------|-----------|---------------|
| PB01 | Projeto C# e repositório GitHub | Alta | Pré-requisito para todo o trabalho em equipe e para a avaliação de versionamento. |
| PB02 | Representação do veículo (RF01) | Alta | `Veiculo` é a base da hierarquia, da frota e da locação; todas as sprints dependem dela. |
| PB03 | Encapsulamento e construtores | Alta | Conceito mínimo exigido na Sprint 1. |
| PB04 | Validação de dados | Alta | Exigência explícita (placa nula/vazia); evita estados inválidos antes de construir sobre a classe. |
| PB05 | Testes iniciais e demonstração | Alta | Entregável obrigatório; critério de aceitação não é só "compila". |
| PB09 | Diagrama de classes inicial | Média | Base para a atualização das sprints 2–4; baixo esforço agora. |

Total planejado: 15 pontos.

## D. Planejamento das tarefas

Unidade de estimativa: **horas** (mantida em todas as tarefas).

| ID | Tarefa | Item relacionado | Responsável | Estimativa (h) |
|----|--------|------------------|-------------|----------------|
| T01 | Criar repositório pelo GitHub Classroom, definir `main` estável e convenção de branches | PB01 | João Pedro dos Santos Martins | 1 |
| T02 | Criar solução .NET com projetos `Models`, `App` e `Tests`; configurar `.gitignore` | PB01 | João Pedro dos Santos Martins | 1 |
| T03 | Elaborar e versionar o Product Backlog inicial | PB01–PB17 | João Pedro dos Santos Martins e Gabriel Henrique Duarte Ferraz | 2 |
| T04 | Modelar `Veiculo` (diagrama de classes inicial) | PB02, PB09 | Victor Bryan Ferreira Lopes | 1 |
| T05 | Implementar atributos privados e propriedades públicas de `Veiculo` | PB02, PB03 | Gabriel Henrique Duarte Ferraz | 1 |
| T06 | Implementar construtores (completo e reduzido) | PB03 | Gabriel Henrique Duarte Ferraz | 1 |
| T07 | Implementar validações (placa, modelo, id, diária) nos setters | PB04 | Gabriel Henrique Duarte Ferraz e Victor Bryan Ferreira Lopes | 2 |
| T08 | Escrever testes automatizados (xUnit) para criação e validações | PB05 | Victor Bryan Ferreira Lopes | 2 |
| T09 | Implementar demonstração em console (criação de objetos e validações) | PB05 | João Pedro dos Santos Martins | 1 |
| T10 | Executar testes, salvar evidências (saída do console e do `dotnet test`) | PB05 | Victor Bryan Ferreira Lopes | 1 |
| T11 | Revisão cruzada via Pull Request e integração na `main` | todos | Todos (revisão cruzada) | 1 |
| T12 | Preencher resultado e retrospectiva da sprint | todos | Todos | 1 |

Total estimado: 15 h.

## E. Critérios de aceitação

| Item | Critérios objetivos |
|------|---------------------|
| PB01 | A solução compila com `dotnet build`; repositório contém `src/`, `tests/`, `docs/`, `.gitignore` e README; `main` contém só código que compila. |
| PB02/PB03 | `Veiculo` tem campos privados e propriedades públicas para Id, Placa, Modelo e ValorBaseDiaria; existe construtor completo e construtor reduzido; nenhum campo é público. |
| PB04 | Placa `null`, `""` e `"   "` lançam `ArgumentException`; Id ≤ 0 e diária ≤ 0 lançam `ArgumentOutOfRangeException`; modelo vazio lança `ArgumentException`; após uma atribuição inválida, o valor anterior permanece. |
| PB05 | Existe ao menos um teste para cada regra acima; a demonstração em console executa e termina com todas as verificações aprovadas (código de saída 0). |
| PB09 | Diagrama de classes com `Veiculo` e seus membros em `docs/diagramas/`. |

## F. Entregáveis previstos

1. Product Backlog inicial priorizado — `docs/product-backlog.md`.
2. Documento de planejamento — `docs/sprints/sprint-1.md` (este arquivo).
3. Código-fonte — `src/UrbanDrive.Models/Entities/Veiculo.cs`.
4. Demonstração de criação de objetos e validação — `src/UrbanDrive.App/Program.cs`.
5. Evidências de testes — `tests/UrbanDrive.Tests/VeiculoTests.cs` e saídas em `docs/evidencias/`.
6. Registro do resultado da sprint — seções G e H abaixo.

## G. Resultado da sprint

| Item ou tarefa | Situação | Evidência | Observações |
|----------------|----------|-----------|-------------|
| PB01 / T01 | Parcialmente concluído | — | Estrutura de pastas e solução prontas; **falta criar o repositório no GitHub Classroom e fazer o primeiro push** (ver `docs/guia-git-sprint1.md`). |
| PB01 / T02 | Concluído | `UrbanDrive.sln`, `.gitignore` | `dotnet build` sem erros nem avisos. |
| PB01 / T03 | Concluído | `docs/product-backlog.md` | 17 itens, com dependências e decisões D1–D3. |
| PB02–PB04 / T04–T07 | Concluído | `Veiculo.cs`, `docs/diagramas/classes-sprint1.md` | Validação além da placa registrada como decisão D3. |
| PB05 / T09 | Concluído | `docs/evidencias/saida-demonstracao-sprint1.txt` | Demonstração executada: 16 de 16 verificações aprovadas. |
| PB05 / T08 | Parcialmente concluído | `tests/UrbanDrive.Tests/VeiculoTests.cs` | Testes xUnit escritos, mas **ainda não executados** (o ambiente em que foram gerados não tinha acesso ao NuGet). O grupo deve rodar `dotnet test` e salvar a saída em `docs/evidencias/`. |
| T10 | Não concluído | — | Depende da execução do `dotnet test` pelo grupo. |
| T11 | Não concluído | — | Depende do uso de branches e Pull Requests no repositório do grupo. |

> Atualize a coluna "Situação" com a realidade do grupo antes de entregar. O enunciado proíbe alterar o planejamento retroativamente para esconder diferenças.

## H. Retrospectiva

_(Rascunho: o grupo deve revisar e ajustar com a experiência real da sprint.)_

- **O que funcionou bem?** Validação nos setters e reuso pelo construtor (`this.Propriedade = valor`) evitou duplicar regras; a demonstração em console serve também como teste de fumaça.
- **Quais foram as principais dificuldades?** Configurar o ambiente de testes: restauração de pacotes do xUnit exige acesso ao NuGet.
- **O planejamento foi adequado ao esforço necessário?** _(o grupo deve comparar as 15 h estimadas com o tempo real gasto)_
- **O que deverá ser melhorado na próxima sprint?** Sugestão: abrir a primeira Pull Request cedo e rodar `dotnet test` antes de cada merge na `main`.
