using System.Globalization;
using UrbanDrive.Models.Entities;

// Garante saída em pt-BR (R$) independentemente da cultura da máquina.
CultureInfo.CurrentCulture = new CultureInfo("pt-BR");
Console.OutputEncoding = System.Text.Encoding.UTF8;

int aprovados = 0, total = 0;

Console.WriteLine("=== UrbanDrive — Sprint 1: demonstração ===\n");

Console.WriteLine("--- 1. Criação de objetos válidos ---");
var v1 = new Veiculo(1, "abc1d23", "Fiat Mobi", 120.50m);
var v2 = new Veiculo(2, "  qwe4r56 ", "  Chevrolet Onix  ");
Console.WriteLine(v1);
Console.WriteLine(v2);
Verificar("Placa normalizada (trim + maiúsculas)", v2.Placa == "QWE4R56");
Verificar("Modelo com espaços removidos", v2.Modelo == "Chevrolet Onix");
Verificar("Construtor reduzido aplica diária padrão", v2.ValorBaseDiaria == Veiculo.ValorDiariaPadrao);

Console.WriteLine("\n--- 2. Validações no construtor ---");
ExigirErro<ArgumentException>("Placa nula", () => new Veiculo(3, null!, "Gol", 90m));
ExigirErro<ArgumentException>("Placa vazia", () => new Veiculo(3, "", "Gol", 90m));
ExigirErro<ArgumentException>("Placa só com espaços", () => new Veiculo(3, "   ", "Gol", 90m));
ExigirErro<ArgumentException>("Modelo vazio", () => new Veiculo(3, "AAA1A11", "", 90m));
ExigirErro<ArgumentOutOfRangeException>("Id zero", () => new Veiculo(0, "AAA1A11", "Gol", 90m));
ExigirErro<ArgumentOutOfRangeException>("Id negativo", () => new Veiculo(-5, "AAA1A11", "Gol", 90m));
ExigirErro<ArgumentOutOfRangeException>("Diária zero", () => new Veiculo(3, "AAA1A11", "Gol", 0m));
ExigirErro<ArgumentOutOfRangeException>("Diária negativa", () => new Veiculo(3, "AAA1A11", "Gol", -10m));

Console.WriteLine("\n--- 3. Validações nas propriedades (setters) ---");
ExigirErro<ArgumentException>("Alterar placa para vazia", () => v1.Placa = "");
Verificar("Placa original preservada após falha", v1.Placa == "ABC1D23");
v1.ValorBaseDiaria = 150m;
Verificar("Alterar diária para valor válido", v1.ValorBaseDiaria == 150m);
ExigirErro<ArgumentOutOfRangeException>("Alterar diária para negativa", () => v1.ValorBaseDiaria = -1m);
Verificar("Diária original preservada após falha", v1.ValorBaseDiaria == 150m);

Console.WriteLine($"\n=== Resultado: {aprovados}/{total} verificações aprovadas ===");
return aprovados == total ? 0 : 1;

void Verificar(string descricao, bool condicao)
{
    total++;
    if (condicao) aprovados++;
    Console.WriteLine($"[{(condicao ? "OK" : "FALHA")}] {descricao}");
}

void ExigirErro<TEx>(string descricao, Action acao) where TEx : Exception
{
    total++;
    try
    {
        acao();
        Console.WriteLine($"[FALHA] {descricao}: nenhuma exceção lançada");
    }
    catch (TEx ex)
    {
        aprovados++;
        Console.WriteLine($"[OK] {descricao}: {typeof(TEx).Name} -> {ex.Message.Split('\n')[0]}");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[FALHA] {descricao}: exceção inesperada {ex.GetType().Name}");
    }
}
