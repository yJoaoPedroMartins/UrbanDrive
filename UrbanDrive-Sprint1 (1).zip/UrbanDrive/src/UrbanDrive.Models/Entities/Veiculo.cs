namespace UrbanDrive.Models.Entities;

/// <summary>
/// Representa um veículo gerenciado pelo UrbanDrive.
/// Sprint 1: classe concreta com encapsulamento e validações.
/// (Será transformada em classe abstrata na Sprint 4.)
/// </summary>
public class Veiculo
{
    // Atributos privados (encapsulamento)
    private int _id;
    private string _placa = string.Empty;
    private string _modelo = string.Empty;
    private decimal _valorBaseDiaria;

    /// <summary>Identificador único do veículo. Deve ser maior que zero.</summary>
    public int Id
    {
        get => _id;
        set
        {
            if (value <= 0)
                throw new ArgumentOutOfRangeException(nameof(Id), value, "O identificador deve ser maior que zero.");
            _id = value;
        }
    }

    /// <summary>Placa do veículo. Não pode ser nula, vazia ou só espaços; é armazenada sem espaços nas pontas e em maiúsculas.</summary>
    public string Placa
    {
        get => _placa;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("A placa não pode ser nula ou vazia.", nameof(Placa));
            _placa = value.Trim().ToUpperInvariant();
        }
    }

    /// <summary>Modelo do veículo. Não pode ser nulo, vazio ou só espaços.</summary>
    public string Modelo
    {
        get => _modelo;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("O modelo não pode ser nulo ou vazio.", nameof(Modelo));
            _modelo = value.Trim();
        }
    }

    /// <summary>Valor-base da diária, em reais. Deve ser maior que zero.</summary>
    public decimal ValorBaseDiaria
    {
        get => _valorBaseDiaria;
        set
        {
            if (value <= 0)
                throw new ArgumentOutOfRangeException(nameof(ValorBaseDiaria), value, "O valor-base da diária deve ser maior que zero.");
            _valorBaseDiaria = value;
        }
    }

    /// <summary>Construtor completo. Todas as atribuições passam pelas validações das propriedades.</summary>
    public Veiculo(int id, string placa, string modelo, decimal valorBaseDiaria)
    {
        Id = id;
        Placa = placa;
        Modelo = modelo;
        ValorBaseDiaria = valorBaseDiaria;
    }

    /// <summary>Construtor reduzido: usa um valor-base de diária padrão.</summary>
    public Veiculo(int id, string placa, string modelo)
        : this(id, placa, modelo, ValorDiariaPadrao)
    {
    }

    /// <summary>Valor-base de diária usado quando nenhum valor é informado.</summary>
    public const decimal ValorDiariaPadrao = 100m;

    public override string ToString() =>
        $"Veículo #{Id} | Placa: {Placa} | Modelo: {Modelo} | Diária-base: {ValorBaseDiaria:C2}";
}
