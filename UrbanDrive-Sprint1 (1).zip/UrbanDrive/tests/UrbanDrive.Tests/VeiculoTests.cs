using UrbanDrive.Models.Entities;
using Xunit;

namespace UrbanDrive.Tests;

public class VeiculoTests
{
    [Fact]
    public void Construtor_DadosValidos_CriaVeiculo()
    {
        var v = new Veiculo(1, "ABC1D23", "Fiat Mobi", 120m);

        Assert.Equal(1, v.Id);
        Assert.Equal("ABC1D23", v.Placa);
        Assert.Equal("Fiat Mobi", v.Modelo);
        Assert.Equal(120m, v.ValorBaseDiaria);
    }

    [Fact]
    public void Construtor_Reduzido_UsaDiariaPadrao()
    {
        var v = new Veiculo(1, "ABC1D23", "Fiat Mobi");
        Assert.Equal(Veiculo.ValorDiariaPadrao, v.ValorBaseDiaria);
    }

    [Fact]
    public void Placa_EhNormalizada()
    {
        var v = new Veiculo(1, "  abc1d23 ", "Fiat Mobi", 120m);
        Assert.Equal("ABC1D23", v.Placa);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void Construtor_PlacaInvalida_LancaArgumentException(string? placa)
    {
        Assert.Throws<ArgumentException>(() => new Veiculo(1, placa!, "Gol", 90m));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("  ")]
    public void Construtor_ModeloInvalido_LancaArgumentException(string? modelo)
    {
        Assert.Throws<ArgumentException>(() => new Veiculo(1, "AAA1A11", modelo!, 90m));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void Construtor_IdInvalido_LancaArgumentOutOfRangeException(int id)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new Veiculo(id, "AAA1A11", "Gol", 90m));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-10)]
    public void Construtor_DiariaInvalida_LancaArgumentOutOfRangeException(int diaria)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new Veiculo(1, "AAA1A11", "Gol", diaria));
    }

    [Fact]
    public void SetPlaca_Vazia_LancaExcecaoEMantemValorAnterior()
    {
        var v = new Veiculo(1, "ABC1D23", "Gol", 90m);

        Assert.Throws<ArgumentException>(() => v.Placa = "");
        Assert.Equal("ABC1D23", v.Placa);
    }

    [Fact]
    public void SetValorBaseDiaria_Valido_Atualiza()
    {
        var v = new Veiculo(1, "ABC1D23", "Gol", 90m);
        v.ValorBaseDiaria = 150m;
        Assert.Equal(150m, v.ValorBaseDiaria);
    }
}
